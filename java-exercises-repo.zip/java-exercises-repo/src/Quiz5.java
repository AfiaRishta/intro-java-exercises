public class Quiz5{
    public static void main(String[]args) {
        int month = 2;
        int newborn=0;
        int onemonth=1;
        int mature=0;

        
        System.out.println("Month:"+month+"numer of pairs:" +(mature+onemonth+newborn));

    for (month=3;month<=12;month++){
        mature=mature+onemonth;
        onemonth=newborn;
        newborn=mature;

        System.out.println("Month:"+month+"numer of pairs:" +(mature+onemonth+newborn));

    }
}
}