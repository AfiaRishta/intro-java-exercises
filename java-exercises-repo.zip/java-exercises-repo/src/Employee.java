import java.util.*;
import java.io.*;
public class Employee {
    public static void main(String[] args) throws IOException{
        
        File fileToOpen = new File("C:\Users\zahin\Downloads\Employee.txt");
        Scanner myFile = new Scanner(fileToOpen);
        String name = myFile.nextLine();
        double hoursWorked = myFile.nextDouble();
        double rateOfPay = myFile.nextDouble();
        double salesTotal =myFile.nextDouble();
        System.out.println("What"+ name );
        myFile.close();
    }
}