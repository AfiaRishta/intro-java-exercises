import java .util.*;
import java.io.*;

  public class Quiz8 {
    public static void main(String[] args) throws IOException{
        
        File fileToOpen = new File("C:/Users/zahin/Downloads/Employee.txt");
        Scanner myFile = new Scanner(fileToOpen);
        String name = myFile.nextLine();
        double hoursWorked = myFile.nextDouble();
        double rateOfPay = myFile.nextDouble();
        double salesTotal =myFile.nextDouble();
        double expectedSalesPerHour = 200.0;
        double bonus = 0.0;
        double expectedsales = expectedSalesPerHour * hoursWorked;

        if (salesTotal >expectedsales ) {
                double excessSales = salesTotal - (expectedSalesPerHour * hoursWorked);
                bonus = 0.10 * excessSales;
            }
            
            double pay = (hoursWorked * rateOfPay) + bonus;

        myFile.close();
    }
}