import java.util.Scanner;

public class PetrolRunningTotal {

    public static void main(String[] args) {
        Scanner readLitres = new Scanner(System.in);
        double litres;
        System.out.println("Enter the number of liters");
        litres = readLitres.nextDouble();

        double amountOfMoney = (litres * 1.5);
        System.out.println("Litres: " + litres);

        for (int count = 1; count <= litres; count++) {
            System.out.println("Step " + count + ": Amount of Money = " + (count * 1.5));
        }

        System.out.println("Total Money = " + amountOfMoney);

        readLitres.close();
    }
}