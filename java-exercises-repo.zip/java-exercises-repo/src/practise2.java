public class practise {
    public static void main(String[]args){
        String s ="hello";
        int length = s.length();
        System.out.println(s + " is of length " + length);
            
        }
    }

