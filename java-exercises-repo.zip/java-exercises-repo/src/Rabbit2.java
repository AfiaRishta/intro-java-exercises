public class Rabbit {

    public static void main(String[] args) {
        int month = 2;
        int mature = 0;
        int newborn =0;
        int onemonth = 1
        

        while ( mature < 5000000) {
            mature = newborn + onemonth;
            month++;
            System.out.println("Month " + month + ": " + mature + " pair(s) of rabbits");
            newborn = onemonth;
            onemonth = mature;
        }

        System.out.println("\nIt will take " + month + " months to reach a rabbit population of 5000000 pairs.");
    }
}