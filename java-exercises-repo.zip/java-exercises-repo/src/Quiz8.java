import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Quiz8 {
    public static void main(String[] args) {
        String fileName = "Employee.txt";
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String name = br.readLine();
            double hoursWorked = Double.parseDouble(br.readLine());
            double rateOfPay = Double.parseDouble(br.readLine());
            double salesTotal = Double.parseDouble(br.readLine());

            double expectedSalesPerHour = 200.0;
            double bonus = 0.0;

            if (salesTotal > expectedSalesPerHour * hoursWorked) {
                double excessSales = salesTotal - (expectedSalesPerHour * hoursWorked);
                bonus = 0.10 * excessSales;
            }

            double pay = (hoursWorked * rateOfPay) + bonus;

            System.out.printf("%s must be paid $%.2f this week.%n", name, pay);
        } catch (IOException e) {
            System.err.println("Error reading from the file: " + e.getMessage());
        }
    }
}
