import java.util.Scanner;

public class ConcatenateStrings {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of seconds: ");
        int totalSeconds = scanner.nextInt();

        int hours = totalSeconds / 3600; // 1 hour = 3600 seconds
        int remainingSeconds = totalSeconds % 3600;
        int minutes = remainingSeconds / 60; // 1 minute = 60 seconds
        int seconds = remainingSeconds % 60;

        System.out.println("Equivalent time: " + hours + " hours, " + minutes + " minutes, " + seconds + " seconds");

        scanner.close();
    }
}

