import java.util.Scanner;

public class HexaicosadecimalNumber {
    private String stringRepresentation;
    private double doubleRepresentation;

    public HexaicosadecimalNumber(String hexaicosadecimal) {
        this.stringRepresentation = hexaicosadecimal.toLowerCase();
        this.doubleRepresentation = hexaicosadecimalStringToDouble(hexaicosadecimal);
    }

    public HexaicosadecimalNumber(double decimal) {
        this.doubleRepresentation = decimal;
        this.stringRepresentation = doubleToHexaicosadecimalString(decimal);
    }

    private String doubleToHexaicosadecimalString(double decimal) {
        boolean isNegative = decimal < 0;

        if (decimal == 0) {
            return "a";
        }

        if (isNegative) {
            decimal = -decimal;
        }
        ;

        int wholePart = (int) decimal;
        double fractionalPart = decimal - wholePart;

        String hexaicosadecimalString = "";

        while (wholePart > 0) {
            int remainder = wholePart % 26;
            char hexChar = (char) (remainder + 'a');
            hexaicosadecimalString = hexChar + hexaicosadecimalString;
            wholePart /= 26;
        }

        if (fractionalPart > 0) {
            hexaicosadecimalString += ".";

            int fractionalDigits = 10;
            for (int i = 0; i < fractionalDigits; i++) {
                fractionalPart *= 26;
                int wholeValue = (int) fractionalPart;
                char hexChar = (char) (wholeValue + 'a');
                hexaicosadecimalString += hexChar;
                fractionalPart -= wholeValue;
            }
        }

        if (isNegative) {
            hexaicosadecimalString = "-" + hexaicosadecimalString;
        }

        return hexaicosadecimalString;
    }

    private double hexaicosadecimalStringToDouble(String hexaicosadecimal) {
        String decimalValue = hexaicosadecimal.toLowerCase();
        boolean isNegative = decimalValue.charAt(0) == '-';

        if (isNegative) {
            decimalValue = decimalValue.substring(1);
        }

        int dotIndex = decimalValue.indexOf('.');
        if (dotIndex == -1) {
            dotIndex = decimalValue.length();
        }

        String wholePart = decimalValue.substring(0, dotIndex);
        String fractionalPart;
        if (dotIndex < decimalValue.length() - 1) {
            
    fractionalPart = decimalValue.substring(dotIndex + 1);
        } else {
    fractionalPart = "";
}


        double result = 0.0;

        for (int i = wholePart.length() - 1; i >= 0; i--) {
            char currentChar = wholePart.charAt(i);
            if (currentChar >= 'a' && currentChar <= 'z') {
                int baseValue = currentChar - 'a';
                int exponent = wholePart.length() - i - 1;
                result += baseValue * Math.pow(26, exponent);
            }
        }

        for (int i = 0; i < fractionalPart.length(); i++) {
            char currentChar = fractionalPart.charAt(i);
            if (currentChar >= 'a' && currentChar <= 'z') {
                int baseValue = currentChar - 'a';
                int exponent = -(i + 1);
                result += baseValue * Math.pow(26, exponent);
            }
        }

        if (isNegative) {
            result = -result;
        }

        return result;
    }
    @Override
    public String toString() {
        return stringRepresentation + " (" + doubleRepresentation + ")";
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Please enter 'h' to convert from hexaicosadecmial to decimal, " +
                    "'d' to convert from decimal, or 'q' to quit:");
            String input = scanner.nextLine().toLowerCase();

            if (input.equals("h")) {
                System.out.println("Please enter your hexaicosadecmial number:");
                String hexaicosadecimal = scanner.nextLine();
                HexaicosadecimalNumber hexaicosNumber = new HexaicosadecimalNumber(hexaicosadecimal);
                System.out.println(hexaicosNumber);
            } else if (input.equals("d")) {
                System.out.println("Please enter your decimal number:");
                double decimal = Double.parseDouble(scanner.nextLine());
                HexaicosadecimalNumber hexaicosNumber = new HexaicosadecimalNumber(decimal);
                System.out.println(hexaicosNumber);
            } else if (input.equals("q")) {
                break;
            } else {
                System.out.println("INVALID INPUT");
            }
        }
        scanner.close();
    }
}